module github.com/v2fly/domain-list-community

go 1.25.12

require (
	github.com/v2fly/v2ray-core/v5 v5.52.0
	google.golang.org/protobuf v1.36.12
)

require (
	github.com/adrg/xdg v0.5.3 // indirect
	github.com/golang/protobuf v1.5.4 // indirect
	golang.org/x/sys v0.46.0 // indirect
)
